package com.example.app;

import com.example.mylib.Lib;
import org.apache.commons.lang3.StringUtils;

public class App {
    public static void main(String[] args) {
        String reversedHello = StringUtils.reverse("Hello, World!");
        System.out.println(reversedHello);
        System.out.println(Lib.reverse("Hello, from mylib!"));
    }
}