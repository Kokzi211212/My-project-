# Gradle Multi-module Project

Modules:
 - mylib: Java library
 - app: Application depending on JARs in libs/ and Commons Lang