package com.example.mylib;

public class Lib {
    public static String reverse(String input) {
        return new StringBuilder(input).reverse().toString();
    }
}