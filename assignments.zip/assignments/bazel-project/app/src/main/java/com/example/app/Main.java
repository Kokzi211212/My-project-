package com.example.app;

import com.example.mylib.Lib;

public class Main {
    public static void main(String[] args) {
        System.out.println(Lib.reverse("Hello, World!"));
    }
}