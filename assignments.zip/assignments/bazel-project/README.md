# Bazel Project

This project has two targets:
 - //mylib: Java library
 - //app: Java binary